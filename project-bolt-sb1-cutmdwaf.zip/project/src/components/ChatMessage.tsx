import React from 'react';
import { User } from 'lucide-react';
import MaveliAvatar from './MaveliAvatar';

interface ChatMessageProps {
  message: string;
  isUser: boolean;
  expression?: 'happy' | 'excited' | 'royal' | 'laughing' | 'greeting' | 'thinking';
}

export default function ChatMessage({ message, isUser, expression = 'happy' }: ChatMessageProps) {
  return (
    <div className={`flex gap-3 mb-4 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      <div className="flex-shrink-0">
        {isUser ? (
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center border-2 border-blue-300 shadow-lg">
            <User size={20} className="text-white" />
          </div>
        ) : (
          <MaveliAvatar expression={expression} />
        )}
      </div>
      
      <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
        isUser 
          ? 'bg-blue-500 text-white rounded-br-md' 
          : 'bg-gradient-to-r from-orange-50 to-yellow-50 border border-orange-200 text-gray-800 rounded-bl-md'
      }`}>
        <p className="text-sm leading-relaxed whitespace-pre-line">{message}</p>
      </div>
    </div>
  );
}