import React from 'react';
import { Crown, Sparkles, Heart, Star } from 'lucide-react';

interface MaveliAvatarProps {
  expression: 'happy' | 'excited' | 'royal' | 'laughing' | 'greeting' | 'thinking';
}

export default function MaveliAvatar({ expression }: MaveliAvatarProps) {
  const getAvatarStyle = () => {
    const baseStyle = "w-16 h-16 rounded-full border-4 border-yellow-400 shadow-xl overflow-hidden relative";
    
    switch (expression) {
      case 'excited':
        return `${baseStyle} animate-bounce border-yellow-500 shadow-yellow-300/50`;
      case 'royal':
        return `${baseStyle} border-yellow-600 shadow-yellow-400/60 animate-pulse`;
      case 'laughing':
        return `${baseStyle} animate-pulse border-orange-400`;
      case 'thinking':
        return `${baseStyle} border-blue-400`;
      case 'greeting':
        return `${baseStyle} border-orange-500 animate-pulse`;
      default:
        return `${baseStyle} border-yellow-400`;
    }
  };

  const getMaveliImage = () => {
    // Using a beautiful Maveli illustration as background
    const baseImageStyle = "absolute inset-0 w-full h-full object-cover";
    
    return (
      <div className="relative w-full h-full">
        {/* Maveli Character - Using CSS to create the traditional look */}
        <div className="absolute inset-0 bg-gradient-to-br from-orange-400 via-yellow-500 to-orange-600 rounded-full">
          {/* Face */}
          <div className="absolute inset-2 bg-gradient-to-br from-amber-200 to-orange-300 rounded-full">
            {/* Eyes */}
            <div className="absolute top-3 left-2 w-1.5 h-1.5 bg-black rounded-full"></div>
            <div className="absolute top-3 right-2 w-1.5 h-1.5 bg-black rounded-full"></div>
            
            {/* Mustache */}
            <div className="absolute top-5 left-1/2 transform -translate-x-1/2 w-4 h-1 bg-black rounded-full"></div>
            
            {/* Mouth based on expression */}
            {expression === 'laughing' && (
              <div className="absolute top-6 left-1/2 transform -translate-x-1/2 w-3 h-1.5 bg-red-600 rounded-full"></div>
            )}
            {expression === 'happy' && (
              <div className="absolute top-6 left-1/2 transform -translate-x-1/2 w-2 h-1 bg-red-500 rounded-full"></div>
            )}
            {expression === 'thinking' && (
              <div className="absolute top-6 left-1/2 transform -translate-x-1/2 w-1.5 h-1 bg-red-400 rounded-full"></div>
            )}
            {(expression === 'excited' || expression === 'greeting') && (
              <div className="absolute top-6 left-1/2 transform -translate-x-1/2 w-3 h-2 bg-red-600 rounded-full"></div>
            )}
            {expression === 'royal' && (
              <div className="absolute top-6 left-1/2 transform -translate-x-1/2 w-2.5 h-1 bg-red-500 rounded-full"></div>
            )}
          </div>
        </div>
        
        {/* Crown */}
        <div className="absolute -top-2 left-1/2 transform -translate-x-1/2">
          <Crown className="text-yellow-400 w-6 h-6 drop-shadow-lg" />
        </div>
        
        {/* Expression-based decorative elements */}
        {expression === 'excited' && (
          <>
            <div className="absolute -top-1 -right-1 text-yellow-400 animate-spin">
              <Sparkles size={12} />
            </div>
            <div className="absolute -bottom-1 -left-1 text-orange-400 animate-bounce">
              <Star size={10} />
            </div>
          </>
        )}
        
        {expression === 'royal' && (
          <>
            <div className="absolute -top-1 -right-1 text-yellow-500 animate-pulse">
              <Crown size={14} />
            </div>
            <div className="absolute -bottom-1 -left-1 text-yellow-400 animate-pulse">
              <Crown size={10} />
            </div>
          </>
        )}
        
        {expression === 'greeting' && (
          <>
            <div className="absolute -top-1 -right-1 text-red-400 animate-pulse">
              <Heart size={12} />
            </div>
            <div className="absolute -bottom-1 -left-1 text-orange-400 animate-bounce">
              <Heart size={10} />
            </div>
          </>
        )}
        
        {expression === 'laughing' && (
          <>
            <div className="absolute -top-1 -right-1 text-yellow-400 animate-bounce">
              <Sparkles size={12} />
            </div>
            <div className="absolute -bottom-1 -left-1 text-orange-400 animate-bounce" style={{ animationDelay: '0.2s' }}>
              <Sparkles size={10} />
            </div>
          </>
        )}
      </div>
    );
  };

  const getGlowEffect = () => {
    switch (expression) {
      case 'excited':
        return "shadow-yellow-400/60 shadow-2xl";
      case 'royal':
        return "shadow-yellow-500/70 shadow-2xl";
      case 'laughing':
        return "shadow-orange-400/60 shadow-2xl";
      case 'greeting':
        return "shadow-red-400/50 shadow-2xl";
      case 'thinking':
        return "shadow-blue-400/50 shadow-xl";
      default:
        return "shadow-yellow-400/50 shadow-xl";
    }
  };

  return (
    <div className={`${getAvatarStyle()} ${getGlowEffect()}`}>
      {getMaveliImage()}
      
      {/* Animated background glow */}
      <div className="absolute inset-0 bg-gradient-to-br from-yellow-200/20 to-orange-200/20 rounded-full animate-pulse"></div>
      
      {/* Royal aura effect */}
      <div className="absolute -inset-1 bg-gradient-to-r from-yellow-400/20 via-orange-400/20 to-yellow-400/20 rounded-full blur-sm animate-pulse"></div>
    </div>
  );
}