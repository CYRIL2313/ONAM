import React from 'react';
import { Calendar, MapPin, Shirt, Utensils, Flower, Smile } from 'lucide-react';

interface QuickActionsProps {
  onActionClick: (action: string) => void;
}

export default function QuickActions({ onActionClick }: QuickActionsProps) {
  const actions = [
    { id: 'events', label: 'Events', icon: Calendar, color: 'bg-green-500' },
    { id: 'dress', label: 'Dress Code', icon: Shirt, color: 'bg-purple-500' },
    { id: 'location', label: 'Location', icon: MapPin, color: 'bg-blue-500' },
    { id: 'sadya', label: 'Sadya', icon: Utensils, color: 'bg-orange-500' },
    { id: 'pookalam', label: 'Pookalam', icon: Flower, color: 'bg-pink-500' },
    { id: 'joke', label: 'Joke', icon: Smile, color: 'bg-yellow-500' },
  ];

  return (
    <div className="p-4 border-t border-orange-100">
      <h3 className="text-sm font-semibold text-gray-600 mb-3">Quick Questions:</h3>
      <div className="flex flex-wrap gap-2">
        {actions.map(({ id, label, icon: Icon, color }) => (
          <button
            key={id}
            onClick={() => onActionClick(id)}
            className={`${color} text-white px-3 py-2 rounded-full text-xs font-medium flex items-center gap-1 hover:scale-105 transition-transform`}
          >
            <Icon size={12} />
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}