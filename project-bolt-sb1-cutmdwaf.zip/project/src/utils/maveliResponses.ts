interface ChatResponse {
  text: string;
  expression: 'happy' | 'excited' | 'royal' | 'laughing' | 'greeting' | 'thinking';
}

export function getMaveliResponse(userMessage: string): ChatResponse {
  const message = userMessage.toLowerCase();

  // Greetings
  if (message.includes('hi') || message.includes('hello') || message.includes('hey')) {
    return {
      text: "Namaskaram! 🙏 Maveli thanne aanu ithu. Ningal evidunnu parayunne? Welcome to my royal kingdom! 👑",
      expression: 'greeting'
    };
  }

  // Events
  if (message.includes('event') || message.includes('program') || message.includes('competition')) {
    return {
      text: `College Onam aaghoshamil pala events undu! 🌼

Pookkalam Competition – 9:30 AM, Main Hall.

Onam Games & Tug of War – 11:00 AM, Ground.

Thiruvathira Dance – 1:00 PM, Auditorium.

Sadya 🍛 – 2:30 PM, Canteen.
Miss aakanda!`,
      expression: 'excited'
    };
  }

  // Dress code
  if (message.includes('dress') || message.includes('wear') || message.includes('attire')) {
    return {
      text: `Traditional wear aanu compulsory 🎉

Boys: Mundu / Dhoti.

Girls: Kasavu Saree / Set Mundu.
Oru royal look venam alle!`,
      expression: 'royal'
    };
  }

  // Location
  if (message.includes('where') || message.includes('location') || message.includes('place')) {
    return {
      text: "Main auditorium aanu valiya programs. Games groundil aayirikkum. Sadya canteenil kaananam 🍌🍛.",
      expression: 'happy'
    };
  }

  // What is Onam
  if (message.includes('what is onam') || message.includes('onam') && message.includes('what')) {
    return {
      text: `Onam ennaal ente (Maveli-yude) Kerala-lekk thirichu varunna oru samayam aanu 👑.
Ee festival unity, prosperity, and oonam sadya undu enna promise aanennu orma kooduthal.`,
      expression: 'royal'
    };
  }

  // Sadya
  if (message.includes('sadya') || message.includes('food') || message.includes('feast')) {
    return {
      text: "Onasadya oru royal feast aanu 🍛🍌. Banana leaf-il 20+ items – Sambar, Avial, Kalan, Thoran, Upperi, Sharkkara Varatti, Payasam… payasam illaatha sadya onam alla!",
      expression: 'excited'
    };
  }

  // Pookalam
  if (message.includes('pookalam') || message.includes('flower') || message.includes('rangoli')) {
    return {
      text: "Pookalam 🌸 ennaal colourful flowers kondu undakkunna oru rangoli pole design aanu. Adhbhutham alle?",
      expression: 'happy'
    };
  }

  // Have you eaten sadya
  if ((message.includes('eaten') && message.includes('sadya')) || message.includes('food') && message.includes('you')) {
    return {
      text: "Haha! Enikku oru 3 payasam minimum venam 🍮… illenkil Onam complete aakilla!",
      expression: 'laughing'
    };
  }

  // Are you real
  if (message.includes('real') || message.includes('genuine') || message.includes('actual')) {
    return {
      text: "Ente makkale, njan ningalude manasilum samskaarathilum jeevikkunnu 👑. Athukondu ippo chatil real aanu njan!",
      expression: 'royal'
    };
  }

  // Joke
  if (message.includes('joke') || message.includes('funny') || message.includes('humor')) {
    return {
      text: "Onam-il thinnu kazhinjappol oru student paranju: 'Sir, lunch break ethra neram?' 👑😂",
      expression: 'laughing'
    };
  }

  // Thank you / Goodbye
  if (message.includes('thank') || message.includes('bye') || message.includes('goodbye')) {
    return {
      text: "Nandi! 🙏 Ningalodoppam samsaarikkunnathu oru valiya santhosham aayirunnu. Onashamsakal once again 🌸👑. Koodi aaghoshikkam!",
      expression: 'greeting'
    };
  }

  // Default fallback
  return {
    text: "Aiyo! Athu ente kaalathil illa! 😅 Vere chodikkamo?",
    expression: 'thinking'
  };
}

export function getQuickActionResponse(action: string): ChatResponse {
  switch (action) {
    case 'events':
      return getMaveliResponse('events');
    case 'dress':
      return getMaveliResponse('dress code');
    case 'location':
      return getMaveliResponse('where');
    case 'sadya':
      return getMaveliResponse('sadya');
    case 'pookalam':
      return getMaveliResponse('pookalam');
    case 'joke':
      return getMaveliResponse('joke');
    default:
      return {
        text: "Aiyo! Athu ente kaalathil illa! 😅 Vere chodikkamo?",
        expression: 'thinking'
      };
  }
}