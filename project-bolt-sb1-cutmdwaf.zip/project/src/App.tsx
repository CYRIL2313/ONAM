import React, { useState, useEffect, useRef } from 'react';
import { Crown, Flower } from 'lucide-react';
import ChatMessage from './components/ChatMessage';
import ChatInput from './components/ChatInput';
import QuickActions from './components/QuickActions';
import { getMaveliResponse, getQuickActionResponse } from './utils/maveliResponses';

interface Message {
  id: number;
  text: string;
  isUser: boolean;
  expression?: 'happy' | 'excited' | 'royal' | 'laughing' | 'greeting' | 'thinking';
}

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    // Initial greeting
    const initialMessage: Message = {
      id: 1,
      text: `Ellavarkkum Onashamsakal! 🌸👑
Njan Maveli aanu… once in a year njan thirichu varunnu ningalodoppam Onam aaghoshikkana. Enthu ariyan ulla?`,
      isUser: false,
      expression: 'greeting'
    };
    setMessages([initialMessage]);
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (text: string) => {
    const userMessage: Message = {
      id: Date.now(),
      text,
      isUser: true,
    };

    setMessages(prev => [...prev, userMessage]);
    setIsTyping(true);

    // Simulate typing delay
    setTimeout(() => {
      const response = getMaveliResponse(text);
      const maveliMessage: Message = {
        id: Date.now() + 1,
        text: response.text,
        isUser: false,
        expression: response.expression
      };

      setMessages(prev => [...prev, maveliMessage]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };

  const handleQuickAction = (action: string) => {
    const response = getQuickActionResponse(action);
    const maveliMessage: Message = {
      id: Date.now(),
      text: response.text,
      isUser: false,
      expression: response.expression
    };

    setMessages(prev => [...prev, maveliMessage]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-yellow-50 to-orange-100">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 via-yellow-500 to-orange-600 text-white p-4 shadow-lg">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <div className="bg-white/20 p-3 rounded-full animate-pulse">
            <Crown className="text-yellow-200 animate-bounce" size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-yellow-200 to-white bg-clip-text text-transparent">
              👑 King Maveli 👑
            </h1>
            <p className="text-yellow-100 text-sm font-medium">Your Royal Onam Festival Guide</p>
          </div>
          <div className="ml-auto flex gap-2">
            <Flower className="text-yellow-200 animate-pulse" size={20} />
            <Flower className="text-pink-200 animate-pulse" size={20} style={{ animationDelay: '0.5s' }} />
            <Crown className="text-yellow-300 animate-bounce" size={18} style={{ animationDelay: '1s' }} />
          </div>
        </div>
      </div>

      {/* Chat Container */}
      <div className="max-w-4xl mx-auto h-[calc(100vh-80px)] flex flex-col">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-1">
          {messages.map((message) => (
            <ChatMessage
              key={message.id}
              message={message.text}
              isUser={message.isUser}
              expression={message.expression}
            />
          ))}
          
          {isTyping && (
            <div className="flex gap-3 mb-4">
              <div className="flex-shrink-0">
                <div className="w-16 h-16 bg-gradient-to-br from-orange-100 to-yellow-100 rounded-full flex items-center justify-center border-3 border-yellow-400 shadow-lg">
                  <div className="text-4xl animate-bounce">🤔</div>
                </div>
              </div>
              <div className="bg-gradient-to-r from-orange-50 to-yellow-50 border border-orange-200 px-4 py-3 rounded-2xl rounded-bl-md">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-orange-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Quick Actions */}
        <QuickActions onActionClick={handleQuickAction} />

        {/* Input */}
        <ChatInput onSendMessage={handleSendMessage} />
      </div>
    </div>
  );
}

export default App;